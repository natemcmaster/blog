using System;
using CodeCampMvc.Models;

namespace CodeCampMvc.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Hello Code Camp";
        }

        public Octocat Avatar()
        {
            return new Octocat
            {
                Name = "Red Polo",
                ImageUri = new Uri("/red-polo.png"),
            };
        }
    }

}
