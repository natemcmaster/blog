using System;

namespace CodeCampMvc.Models
{
    public class Octocat
    {
        public string Name { get; set; }
        public Uri ImageUri { get; set ;}
    }
}
